function challenge5(text){
    let words = text.split(' ');
    return words.length;

}
console.log(`Output:`);
console.log(challenge5("Hello world"));
console.log(challenge5("This is the best day"));
console.log(challenge5("a bb ccc ddddddd e"));