function challenge6(votes) {
    if (votes.length === 0) {
        console.log("There is not vote yet");
        return;
    }

    const voteCounts = {};
    for (let vote of votes) {
        voteCounts[vote] = (voteCounts[vote] || 0) + 1;
    }

    // Find the maximum vote count
    const maxVotes = Math.max(...Object.values(voteCounts));

    // Find candidates with the maximum votes
    const winners = Object.keys(voteCounts).filter(candidate => voteCounts[candidate] === maxVotes);

    if (winners.length === 1) {
        console.log(`${winners[0]} is the winner`);
    } else {
        console.log(`${winners.join(' and ')} are both winners`);
    }
}
console.log(`--Result--`);
challenge6(['A', 'B', 'A', 'C', 'A']);
challenge6(['A', 'B', 'B', 'C', 'A']); 
challenge6([]); 