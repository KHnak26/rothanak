function challenge3(array) {

    if(array == 0){
        return 0;
    }

    let sum = 0;
    for (let i = 0; i < array.length; i++) {
        sum += array[i];
    }
    return sum / array.length;

}
console.log(`Output:`);
console.log(challenge3([85, 90, 78, 92])); 
console.log(challenge3([10, 20, 30]));  
console.log(challenge3([]));             
