let title = "Atomic Clock"

function Header() {
    return(
        <header>
            <h1>The amazing atomic clock</h1>
        </header>
    );
}

export default Header;