function Header() {
  return (
    <header class="block">
        <h1>Welcome!</h1>
        <p></p>
    </header>
  );
}

export default Header;