export const ALL_PNV_TEACHERS = [
  {
    firstName: "My",
    lastName: "Ngo",
    title: "IT Trainer",
  },
  {
    firstName: "sd",
    lastName: "Ngo",
    title: "IT Trainer",
  },
  {
    firstName: "sadad",
    lastName: "Ngo",
    title: "IT Trainer",
  },
  {
    firstName: "asdadsad",
    lastName: "Ngo",
    title: "IT Trainer",
  },
];
