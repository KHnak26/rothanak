export default function Card({ card }) {
    return (
        <li key={card.id} className="card-item">
            <button>
                <img src={card.image.src} alt={card.image.alt} />
                <h3>{card.title}</h3>
                <p>{card.description}</p>
            </button>
        </li>
    );
}
