/* Your data here */
import Kendrick_Lamar from './assets/kendrick.jpg';
import Taylor_Swift from './assets/taylor.jpg';
import CC from './assets/CC.jpg';
import Jack_ma from './assets/Jackma.jpg';

export const AVAILABLE_ITEM = [
    {
        id: "p1",
        title: "Kendrick Lamar",
        image: {
            src: Kendrick_Lamar,
            alt: "Kendrick Lamar",
        },
        description: "American rapper, songwriter, and record producer known for his complex lyrics and storytelling."
    },
    {
        id: "p2",
        title: "Taylor Swift",
        image: {
            src: Taylor_Swift,
            alt: "Taylor Swift",
        },
        description: "American singer-songwriter famous for her genre-spanning music and storytelling abilities."
    },
    {
        id: "p3",
        title: "Central Cee",
        image: {
            src: CC,
            alt: "Justin Bieber",
        },
        description: "British rapper, songwriter, and freestyle artist known for his lyrical prowess."
    },
    {
        id: "p4",
        title: "Jack Ma",
        image: {
            src: Jack_ma,
            alt: "Jack Ma",
        },
        description: "Chinese business magnate, investor, and philanthropist, best known as the co-founder of Alibaba."
    },
];
