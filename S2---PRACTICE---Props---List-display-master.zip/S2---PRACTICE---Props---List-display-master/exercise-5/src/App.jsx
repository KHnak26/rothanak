import Card from "./components/Card.jsx";
import { AVAILABLE_ITEM  } from "./data.js";

function App() {
  return (
    <>
    	<header>
         <h1> Card Items </h1>
      </header>
      <main>
        <section className="places-category">
          <ul className="place">
            {AVAILABLE_ITEM.map((card) => (
              <Card key = {card.id} card = {card} />
            ))} 
          </ul>
        </section>
      </main>
    </>
  );
}

export default App;
