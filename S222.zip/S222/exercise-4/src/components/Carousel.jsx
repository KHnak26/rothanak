import React, { useState } from "react";
import { BsArrowLeftCircleFill, BsArrowRightCircleFill } from "react-icons/bs";

export const Carousel = ({ images }) => {
  const [currentImage, setCurrentImage] = useState(0);

  // Handle left button click (previous image)
  function handleLeftClick() {
    setCurrentImage((prevIndex) => 
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  }

  // Handle right button click (next image)
  function handleRightClick() {
    setCurrentImage((prevIndex) => 
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  }

  return (
    <div className="carousel">
      <BsArrowLeftCircleFill 
        className="arrow arrow-left" 
        onClick={handleLeftClick} 
      />

      {/* Display the current image */}
      <img 
        src={images[currentImage].src} 
        alt={images[currentImage].alt} 
        className="slide" 
      />

      <BsArrowRightCircleFill 
        className="arrow arrow-right" 
        onClick={handleRightClick} 
      />
    </div>
  );
};
