import React, { useState } from "react";

function App() {
  // State for inputs, sum, and error tracking
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [sum, setSum] = useState("");
  const [error, setError] = useState(false);

  function onA(event) {
    setA(event.target.value);
  }

  function onB(event) {
    setB(event.target.value);
  }

  function computeSum() {
    const numA = parseFloat(a);
    const numB = parseFloat(b);

    if (!isNaN(numA) && !isNaN(numB)) {
      setSum(numA + numB);
      setError(false);
    } else {
      setSum("A and B shall be numbers !");
      setError(true);
    }
  }

  return (
    <main>
      <h1>Calculator</h1>

      <label>A =</label>
      <input type="text" value={a} onKeyUp={onA} onChange={onA}/>

      <label>B =</label>
      <input type="text" value={b} onKeyUp={onB} onChange={onB} />

      <label>A + B =</label>
      <input
        type="text"
        value={sum}
        disabled
        style={{ color: error ? "red" : "white" }}
      />

      <button onClick={computeSum}>Compute</button>
    </main>
  );
}

export default App;
